# SZEYMAR QUALITY APP — Android MVP

## O que esta primeira versão faz
- Seleciona um vídeo pela galeria/gerenciador de arquivos.
- Lê as dimensões e a orientação do vídeo.
- Exporta MP4 com H.264 e áudio AAC.
- Redimensiona mantendo a proporção para que o lado maior tenha 3840 px:
  - paisagem: 3840 × altura proporcional;
  - vertical: largura proporcional × 3840.
- Mostra progresso e salva em `Filmes/Szeymar Quality App`.

## Limite importante
Esta versão faz upscale geométrico por Media3 Presentation. Ela **não** contém um modelo de super-resolução neural, não recupera detalhes que não existem na origem e não é equivalente ao Topaz Video AI. O tamanho de saída é 4K-class em pixels, mas a qualidade percebida depende do original. Alguns aparelhos podem recusar a codificação 4K H.264 por limitações do encoder.

## Como abrir e compilar
1. Instale Android Studio em um computador.
2. Extraia o ZIP.
3. Abra a pasta `SzeymarQualityApp` no Android Studio.
4. Aguarde a sincronização do Gradle e aceite a instalação dos componentes solicitados.
5. Conecte o Galaxy A07 por USB com depuração USB habilitada ou use um emulador.
6. Clique em Run para instalar a versão de teste.

O projeto requer JDK 17 e Android SDK 36. Não inclui APK pré-compilado nem Gradle Wrapper.

## Tecnologias
- Kotlin
- AndroidX Activity
- Jetpack Media3 Transformer 1.11.1
- Android MediaStore

## Próximas etapas para IA real
Integrar um modelo de super-resolução temporal/espacial compatível com Android (por exemplo, via TFLite/MediaPipe ou ONNX Runtime), testar memória e velocidade no Helio G99 e só então ativar os controles AI Upscale, Denoise e Face Recovery.
