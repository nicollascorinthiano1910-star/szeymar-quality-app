package com.szeymar.quality

import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@UnstableApi
class MainActivity : ComponentActivity() {
    private val cyan = Color.rgb(69, 199, 255)
    private val bg = Color.rgb(8, 13, 20)
    private val panel = Color.rgb(18, 29, 42)
    private var selectedUri: Uri? = null
    private var sourceWidth = 0
    private var sourceHeight = 0
    private var transformer: Transformer? = null
    private var isExporting = false
    private lateinit var status: TextView
    private lateinit var videoInfo: TextView
    private lateinit var progress: ProgressBar
    private lateinit var exportButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private var outputFile: File? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedUri = uri
            readVideoInfo(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(24))
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "SZEYMAR"
            textSize = 29f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "QUALITY APP  •  VIDEO UPSCALER"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        page.addView(subtitle, matchWrap())
        addSpace(page, 28)

        val hero = TextView(this).apply {
            text = "4K UHD EXPORT"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(22), dp(12), dp(8))
            setBackgroundColor(panel)
        }
        page.addView(hero, matchWrap())

        val resolution = TextView(this).apply {
            text = "3840 px no lado maior • MP4 • H.264 + AAC"
            textSize = 12f
            setTextColor(Color.rgb(172, 190, 207))
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(18))
            setBackgroundColor(panel)
        }
        page.addView(resolution, matchWrap())
        addSpace(page, 22)

        val pickButton = makeButton("ESCOLHER VÍDEO")
        pickButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        page.addView(pickButton, matchWrap())

        videoInfo = TextView(this).apply {
            text = "Nenhum vídeo selecionado"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), dp(18))
        }
        page.addView(videoInfo, matchWrap())

        exportButton = makeButton("EXPORTAR EM 4K MP4")
        exportButton.isEnabled = false
        exportButton.alpha = 0.45f
        exportButton.setOnClickListener { startExport() }
        page.addView(exportButton, matchWrap())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            visibility = View.GONE
        }
        val progressParams = matchWrap()
        progressParams.topMargin = dp(18)
        page.addView(progress, progressParams)

        status = TextView(this).apply {
            text = "Pronto para importar"
            textSize = 12f
            setTextColor(Color.rgb(170, 190, 208))
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(12), dp(6), dp(8))
        }
        page.addView(status, matchWrap())

        addSpace(page, 12)
        val note = TextView(this).apply {
            text = "IMPORTANTE\\nEsta versão exporta um arquivo com dimensões 4K reais, preservando a proporção do vídeo. Isso é upscaling por redimensionamento, não reconstrução de detalhes por IA. Os modelos de IA ainda não estão integrados. O aparelho pode demorar ou não suportar a codificação 4K em alguns arquivos."
            textSize = 11f
            setTextColor(Color.rgb(145, 163, 180))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        page.addView(note, matchWrap())

        val scroll = android.widget.ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun readVideoInfo(uri: Uri) {
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val rawW = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val rawH = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            retriever.release()
            if (rawW <= 0 || rawH <= 0) throw IllegalStateException("Não foi possível ler as dimensões.")
            if (rotation == 90 || rotation == 270) {
                sourceWidth = rawH
                sourceHeight = rawW
            } else {
                sourceWidth = rawW
                sourceHeight = rawH
            }
            val target = targetDimensions(sourceWidth, sourceHeight)
            videoInfo.text = "VÍDEO SELECIONADO\\n${sourceWidth} × ${sourceHeight}\\nSaída: ${target.first} × ${target.second} • MP4"
            exportButton.isEnabled = true
            exportButton.alpha = 1f
            status.text = "Vídeo pronto para exportação"
        } catch (e: Exception) {
            selectedUri = null
            exportButton.isEnabled = false
            exportButton.alpha = 0.45f
            status.text = "Não consegui ler esse vídeo: ${e.message ?: "formato não suportado"}"
        }
    }

    private fun targetDimensions(width: Int, height: Int): Pair<Int, Int> {
        val longSide = 3840.0
        val ratio = width.toDouble() / height.toDouble()
        return if (width >= height) {
            3840 to even((longSide / ratio).roundToInt())
        } else {
            even((longSide * ratio).roundToInt()) to 3840
        }
    }

    private fun even(value: Int) = max(2, if (value % 2 == 0) value else value - 1)

    private fun startExport() {
        val uri = selectedUri ?: return
        if (isExporting) return

        val out = File(cacheDir, "szeymar_${System.currentTimeMillis()}.mp4")
        outputFile = out
        val dims = targetDimensions(sourceWidth, sourceHeight)
        val presentation = Presentation.createForWidthAndHeight(
            dims.first, dims.second, Presentation.LAYOUT_SCALE_TO_FIT
        )
        val mediaItem = MediaItem.fromUri(uri)
        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), listOf(presentation)))
            .build()

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                isExporting = false
                progress.visibility = View.GONE
                status.text = "Salvando MP4 na galeria…"
                saveToGallery(out, dims.first, dims.second)
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                isExporting = false
                progress.visibility = View.GONE
                exportButton.isEnabled = true
                status.text = "Falha na exportação: ${exportException.message ?: "codec ou resolução não suportados"}"
                out.delete()
            }
        }

        try {
            transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            isExporting = true
            exportButton.isEnabled = false
            progress.progress = 0
            progress.visibility = View.VISIBLE
            status.text = "Preparando exportação 4K…"
            transformer?.start(edited, out.absolutePath)
            pollProgress()
        } catch (e: Exception) {
            isExporting = false
            exportButton.isEnabled = true
            progress.visibility = View.GONE
            status.text = "Não foi possível iniciar: ${e.message ?: "erro desconhecido"}"
            out.delete()
        }
    }

    private fun pollProgress() {
        if (!isExporting) return
        val t = transformer ?: return
        try {
            val state = t.getProgress(progressHolder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.progress = progressHolder.progress
                status.text = String.format(Locale.US, "Exportando MP4 4K… %d%%", progressHolder.progress)
            }
        } catch (_: Exception) { }
        handler.postDelayed({ pollProgress() }, 500)
    }

    private fun saveToGallery(file: File, width: Int, height: Int) {
        Thread {
            var savedUri: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "SZEYMAR_4K_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    if (Build.VERSION.SDK_INT >= 29) {
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Szeymar Quality App")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                }
                savedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Não foi possível criar o arquivo na galeria.")
                contentResolver.openOutputStream(savedUri!!)?.use { output ->
                    FileInputStream(file).use { input -> input.copyTo(output) }
                } ?: throw IllegalStateException("Não foi possível gravar o MP4.")
                if (Build.VERSION.SDK_INT >= 29) {
                    val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(savedUri!!, done, null, null)
                }
                runOnUiThread {
                    progress.visibility = View.GONE
                    status.text = "Concluído! MP4 ${width} × ${height} salvo em Filmes/Szeymar Quality App."
                    exportButton.isEnabled = true
                    Toast.makeText(this, "Vídeo salvo na galeria!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                if (savedUri != null) contentResolver.delete(savedUri!!, null, null)
                runOnUiThread {
                    status.text = "Exportado, mas não consegui salvar na galeria: ${e.message}"
                    exportButton.isEnabled = true
                }
            } finally {
                file.delete()
            }
        }.start()
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.rgb(5, 15, 23))
        setBackgroundColor(cyan)
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
